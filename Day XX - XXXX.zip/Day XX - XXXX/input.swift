import Foundation

// Puzzle input copied from the AoC website.
let inputLines: [String] = """
tbd
""".components(separatedBy: .newlines)

