// inputLines contains the input data, an array of strings.


func solve1() {
	print("Part 1 is not solved yet.")
}

func solve2() {
	print("Part 2 is not solved yet.")
}

solve1()
solve2()
